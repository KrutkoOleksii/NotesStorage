package com.example.notesStorage.swagger;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("api/note")
public class NoteController {


}
