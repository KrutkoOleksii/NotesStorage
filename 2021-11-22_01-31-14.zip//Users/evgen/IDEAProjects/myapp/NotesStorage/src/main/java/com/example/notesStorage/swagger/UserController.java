package com.example.notesStorage.swagger;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("api/user")
public class UserController {


}
