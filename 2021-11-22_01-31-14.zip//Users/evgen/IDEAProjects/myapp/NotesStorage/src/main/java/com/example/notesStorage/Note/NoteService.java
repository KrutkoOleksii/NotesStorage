package com.example.notesStorage.Note;

import org.springframework.stereotype.Service;

@Service
public interface NoteService extends NoteRepository {


}
