package com.example.notesStorage.auth;

import org.springframework.stereotype.Service;

@Service
public interface UserService extends UserRepository {


}
