package com.example.notesStorage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotesStorageApplicationTests {

	@Test
	void contextLoads() {
	}

}
