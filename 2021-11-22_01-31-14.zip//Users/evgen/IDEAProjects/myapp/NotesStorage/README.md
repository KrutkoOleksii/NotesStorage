# NotesStorage

before the start of application you have to add environment variables:
  DB_USERNAME - username of user to connect to the database
  DB_PASSWORD - password of user
  DB_URL - database URL

for example:
  export DB_USERNAME=postgres
  export DB_PASSWORD=super_password
  export DB_URL=jdbc:postgresql://localhost:5432/postgres
